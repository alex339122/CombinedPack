
float time = GameTime * speed;

float getWaveOffset() {
    // --- RUST-PROJECT UNIVERSAL WATER PATCH (VULKAN & OPENGL COMPLIANT) ---
    float currentAlpha = texture(Sampler0, UV0).a;

    // Использование явного float-конструктора вместо суффикса 'f' 
    // Это гарантирует корректный парсинг как в SPIR-V (Vulkan), так и в GLSL (Sodium/OptiFine)
    bool isVanillaWater = abs(currentAlpha - float(0.70588)) < float(0.002);
    bool isClearWater   = abs(currentAlpha - float(0.34510)) < float(0.002);

    if (!(isVanillaWater || isClearWater)) {
        return float(0.0);
    }
    // ----------------------------------------------------------------------
    
    float x = abs(Position.x - float(8.0));
    float z = abs(Position.z - float(8.0));

    float xWave = float(1.1) * height * sin((round(x * frequency) + time * float(0.9)));
    float zWave = float(0.9) * height * cos((round(z * frequency) + time * float(1.1)));

    return (xWave + zWave) * float(0.25);
}
