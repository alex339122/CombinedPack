float leavesTime = GameTime * speed;

float getLeavesZOffset() {
    float currentAlpha = texture(Sampler0, UV0).a;
    bool isCustomLeaves = currentAlpha > float(0.98) && currentAlpha < float(0.995);
    
    if (!isCustomLeaves) {
        return float(0.0);
    }
    
    float x = abs(Position.x - float(8.0));
    float z = abs(Position.z - float(8.0));

    float xWave = float(1.1) * height * sin((round(x * frequency) + leavesTime * float(0.9)));
    float zWave = float(0.9) * height * cos((round(z * frequency) + leavesTime * float(1.1)));

    return (xWave + zWave) * float(0.25);
}

float getLeavesXOffset() {
    float currentAlpha = texture(Sampler0, UV0).a;
    bool isCustomLeaves = currentAlpha > float(0.98) && currentAlpha < float(0.995);
    
    if (!isCustomLeaves) {
        return float(0.0);
    }
    
    float x = abs(Position.x - float(8.0));
    float z = abs(Position.z - float(8.0));

    float xWave = float(1.1) * height * cos((round(x * frequency) + leavesTime * float(0.9)));
    float zWave = float(0.9) * height * sin((round(z * frequency) + leavesTime * float(1.1)));

    return (xWave + zWave) * float(0.25);
}
